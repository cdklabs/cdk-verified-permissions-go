import { RestApi } from 'aws-cdk-lib/aws-apigateway';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as kms from 'aws-cdk-lib/aws-kms';
import { IResource, Resource } from 'aws-cdk-lib/core';
import { Construct } from 'constructs';
import { Policy, PolicyDefinitionProperty } from './policy';
export interface Tag {
    readonly key: string;
    readonly value: string;
}
export interface Schema {
    readonly cedarJson: string;
}
export interface ValidationSettings {
    readonly mode: ValidationSettingsMode;
}
/**
 * Validation Settings mode, according to the Cloudformation PolicyStore resource
 */
export declare enum ValidationSettingsMode {
    OFF = "OFF",
    STRICT = "STRICT"
}
export declare enum DeletionProtectionMode {
    ENABLED = "ENABLED",
    DISABLED = "DISABLED"
}
/**
 * Encryption settings using a customer-managed KMS key.
 */
export interface KmsEncryptionSettings {
    /**
     * The KMS key to use for encryption. This can be either a Key construct or an IKey reference.
     */
    readonly key: kms.IKey;
    /**
     * Additional encryption context key-value pairs.
     *
     * @default - No additional encryption context.
     */
    readonly encryptionContext?: Record<string, string>;
}
/**
 * Encryption settings for the policy store. This is a union type - provide either
 * `awsOwnedKey` set to true for AWS owned encryption, or `customerManagedKey` for
 * customer-managed KMS key encryption. These options are mutually exclusive.
 */
export interface EncryptionSettings {
    /**
     * Use an AWS owned key for encryption.
     * Cannot be specified together with `customerManagedKey`.
     *
     * @default - false
     */
    readonly awsOwnedKey?: boolean;
    /**
     * Use a customer-managed KMS key for encryption.
     * Cannot be specified together with `awsOwnedKey`.
     *
     * @default - undefined
     */
    readonly customerManagedKey?: KmsEncryptionSettings;
}
export interface IPolicyStore extends IResource {
    /**
     * ARN of the Policy Store.
     *
     * @attribute
     */
    readonly policyStoreArn: string;
    /**
     * ID of the Policy Store.
     *
     * @attribute
     */
    readonly policyStoreId: string;
    /**
     *
     * Adds an IAM policy statement associated with this policy store to an IAM
     * principal's policy.
     *
     * @param grantee The principal (no-op if undefined)
     * @param actions The set of actions to allow (i.e. "verifiedpermissions:IsAuthorized", "verifiedpermissions:ListPolicies", ...)
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Permits an IAM principal all read operations on the policy store: GetIdentitySource,
     * GetPolicy, GetPolicyStore, GetPolicyTemplate,
     * GetSchema, ListIdentitySources, ListPolicies, ListPolicyTemplates.
     *
     * @param grantee
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Permits an IAM principal all write & read operations on the policy store: CreateIdentitySource,
     * CreatePolicy,CreatePolicyTemplate, DeleteIdentitySource, DeletePolicy,
     * DeletePolicyTemplate, PutSchema, UpdateIdentitySource, UpdatePolicy, UpdatePolicyTemplate.
     *
     * @param grantee
     */
    grantWrite(grantee: iam.IGrantable): iam.Grant;
    /**
     * Permits an IAM principal all auth operations on the policy store:
     * IsAuthorized, IsAuthorizedWithToken
     * @param grantee
     */
    grantAuth(grantee: iam.IGrantable): iam.Grant;
}
export interface PolicyStoreProps {
    /**
     * This attribute is not required from an API point of view.
     * It represents the schema (in Cedar) to be applied to the PolicyStore.
     *
     * @default - No schema.
     */
    readonly schema?: Schema;
    /**
     * The policy store's validation settings.
    */
    readonly validationSettings: ValidationSettings;
    /**
     * The policy store's description
     *
     * @default - No description.
     */
    readonly description?: string;
    /**
     * The policy store's deletion protection
     * @default - If not provided, the Policy store will be created with deletionProtection = "DISABLED"
     */
    readonly deletionProtection?: DeletionProtectionMode;
    /**
     * The tags assigned to the policy store
     *
     * @default - none
     */
    readonly tags?: Tag[];
    /**
     * The encryption settings for the policy store.
     * If not specified, the policy store will use the default AWS owned key encryption.
     *
     * @default - AWS owned key encryption.
     */
    readonly encryptionSettings?: EncryptionSettings;
}
export interface AddPolicyOptions {
    /**
     * The id of the Policy.
     */
    readonly policyId: string;
    /**
     * The configuration of the Policy.
     */
    readonly policyConfiguration: PolicyDefinitionProperty;
}
export interface PolicyStoreAttributes {
    /**
     * The ARN of the Amazon Verified Permissions Policy Store.
     * One of this, or `policyStoreId`, is required.
     *
     * @default - no PolicyStore arn
     */
    readonly policyStoreArn?: string;
    /**
     * The id of the Amazon Verified Permissions PolicyStore.
     * One of this, or `policyStoreArn`, is required.
     *
     * @default - no PolicyStore id
     */
    readonly policyStoreId?: string;
}
declare abstract class PolicyStoreBase extends Resource implements IPolicyStore {
    abstract readonly policyStoreArn: string;
    abstract readonly policyStoreId: string;
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    grantAuth(grantee: iam.IGrantable): iam.Grant;
    grantRead(grantee: iam.IGrantable): iam.Grant;
    grantWrite(grantee: iam.IGrantable): iam.Grant;
}
export declare class PolicyStore extends PolicyStoreBase {
    /**
     * Create a PolicyStore construct that represents an external policy store via policy store id.
     *
     * @param scope The parent creating construct (usually `this`).
     * @param id The construct's name.
     * @param policyStoreId The PolicyStore's id.
     */
    static fromPolicyStoreId(scope: Construct, id: string, policyStoreId: string): IPolicyStore;
    /**
     * Create a PolicyStore construct that represents an external PolicyStore via policy store arn.
     *
     * @param scope The parent creating construct (usually `this`).
     * @param id The construct's name.
     * @param policyStoreArn The PolicyStore's ARN.
     */
    static fromPolicyStoreArn(scope: Construct, id: string, policyStoreArn: string): IPolicyStore;
    /**
     * Creates a PolicyStore construct that represents an external Policy Store.
     *
     * @param scope The parent creating construct (usually `this`).
     * @param id The construct's name.
     * @param attrs A `PolicyStoreAttributes` object.
     */
    static fromPolicyStoreAttributes(scope: Construct, id: string, attrs: PolicyStoreAttributes): IPolicyStore;
    /**
     * This method generates a schema based on an swagger file. It makes the same assumptions and decisions
     * made in the Amazon Verified Permissions console. This feature is built for swagger files generated from an Amazon API Gateway
     * export. It's possible that some swagger files generated by other tools will not work. In that case, please
     * file an issue.
     * @param swaggerFilePath absolute path to a swagger file in the local directory structure, in json format
     * @param groupEntityTypeName optional parameter to specify the group entity type name. If passed, the schema's User type will have a parent of this type.
     */
    static schemaFromOpenApiSpec(swaggerFilePath: string, groupEntityTypeName?: string): Record<string, Record<string, any>>;
    /**
     * This method generates a schema based on an AWS CDK RestApi construct. It makes the same assumptions
     * and decisions made in the Amazon Verified Permissions console.
     *
     * @param restApi The RestApi construct instance from which to generate the schema.
     * @param groupEntityTypeName Specifies a group entity type name. If passed, the schema's User type will have a parent of this type.
     */
    static schemaFromRestApi(restApi: RestApi, groupEntityTypeName?: string): Record<string, Record<string, any>>;
    private readonly policyStore;
    /**
     * ARN of the Policy Store.
     *
     * @attribute
     */
    readonly policyStoreArn: string;
    /**
     * ID of the Policy Store.
     *
     * @attribute
     */
    readonly policyStoreId: string;
    /**
     * Name of the Policy Store.
     */
    readonly policyStoreName: string;
    /**
     * Schema definition of the Policy Store.
     */
    readonly schema?: Schema;
    /**
     * Validation Settings of the Policy Store.
     */
    readonly validationSettings: ValidationSettings;
    /**
     * Description of the Policy Store
     */
    readonly description?: string;
    /**
     * Deletion protection of the Policy Store
     */
    readonly deletionProtection?: DeletionProtectionMode;
    /**
     * Encryption settings of the Policy Store
     */
    readonly encryptionSettings?: EncryptionSettings;
    constructor(scope: Construct, id: string, props?: PolicyStoreProps);
    private buildEncryptionSettings;
    /**
     * Add multiple policies to the policy store
     *
     * @param policyDefinitions An array of policy options for the policy stores policies.
     * @returns An array of created policy constructs.
     */
    addPolicies(policyDefinitions: AddPolicyOptions[]): Policy[];
    /**
     * Takes in an absolute path to a directory containing .cedar files and adds the contents of each
     * .cedar file as policies to this policy store (searching recursively if needed).
     * Parses the policies with cedar-wasm and, if the policy store has a schema,
     * performs semantic validation of the policies as well.
     * Organizes policies with dependencies to avoid CloudFormation throttling and resource conflicts.
     * @param absolutePath a string representing an absolute path to the directory containing your policies
     * @param recursive a boolean representing whether or not to search the directory recursively for .cedar files
     * @returns An array of created Policy constructs.
     */
    addPoliciesFromPath(absolutePath: string, recursive?: boolean): Policy[];
}
export {};
