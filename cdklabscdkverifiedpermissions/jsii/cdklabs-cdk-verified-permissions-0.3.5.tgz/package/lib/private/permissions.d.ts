export declare const AUTH_ACTIONS: string[];
export declare const READ_ACTIONS: string[];
export declare const WRITE_ACTIONS: string[];
